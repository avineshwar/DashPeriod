//
//  ViewController.swift
//  MenstrualBuddy
//
//  Created by Shristi Hingle on 02/11/16.
//  Copyright © 2016 Shristi Hingle. All rights reserved.
//

import UIKit
import HealthKit


class ViewController: UIViewController {
    
    let healthStore = HKHealthStore()
    var date: Date!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let typestoRead = Set([
            HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.menstrualFlow)!
            ])
        
        let typestoShare = Set([
            HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.menstrualFlow)!
            ])
        
        self.healthStore.requestAuthorization(toShare: typestoShare, read: typestoRead) { (success, error) -> Void in
            if success == false {
                NSLog(" Display not allowed")
            }
            else
            {
                NSLog("Success")
            }
        }
    }
    
    
    
    @IBAction func stop(_ sender: AnyObject) {
        date = Date()
        saveMenstruationInformation()
        retrieveMenstruationInformation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func saveMenstruationInformation() {
        
        // date and date are NSDate objects
        if let menstrualType = HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.menstrualFlow) {
            
            // we create our new object we want to push in Health app
            let object = HKCategorySample(type:menstrualType, value: HKCategoryValueMenstrualFlow.heavy.rawValue, start: self.date, end: self.date, metadata: [HKMetadataKeyMenstrualCycleStart: true] )
            
            // at the end, we save it
            healthStore.save(object, withCompletion: { (success, error) -> Void in
                
                if error != nil {
                    // something happened
                    return
                }
                
                if success {
                    print("My new data was saved in HealthKit")
                    
                } else {
                    print ("\(object))")
                }
                
            })
            
            
            let object2 = HKCategorySample(type:menstrualType, value: HKCategoryValueMenstrualFlow.heavy.rawValue, start: self.date, end: self.date, metadata: [HKMetadataKeyMenstrualCycleStart: true] )
            
            healthStore.save(object2, withCompletion: { (success, error) -> Void in
                if error != nil {
                    // something happened
                    return
                }
                
                if success {
                    print("My new data (2) was saved in HealthKit")
                } else {
                    // something happened again
                }
                
            })
            
        }
        
    }
    
    func retrieveMenstruationInformation() {
        
        // first, we define the object type we want
        if let menstrualType = HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.menstrualFlow) {
            
            // Use a sortDescriptor to get the recent data first
            let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
            
            // we create our query with a block completion to execute
            let query = HKSampleQuery(sampleType: menstrualType, predicate: nil, limit: 30, sortDescriptors: [sortDescriptor]) { (query, tmpResult, error) -> Void in
                
                if error != nil {
                    
                    // something happened
                    return
                    
                }
                
                if let result = tmpResult {
                    
                    // do something with my data
                    for item in result {
                        if let sample = item as? HKCategorySample {
                            let value = (sample.value == HKCategoryValueMenstrualFlow.heavy.rawValue) ? "Heavy" : "Menstrual Flow"
                            print("Healthkit Menstrual Flow: \(sample.startDate) \(sample.endDate) - value: \(value)")
                        }
                    }
                }
            }
            
            // finally, we execute our query
            healthStore.execute(query)
        }
    }
    
    
}

